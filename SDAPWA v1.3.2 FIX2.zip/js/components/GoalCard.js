// SDAPWA v1.0.0 - Goal Card Component
const GoalCard={render(a){return'<div class="goal-card"></div>'}};window.GoalCard=GoalCard;console.log('✓ GoalCard loaded');
