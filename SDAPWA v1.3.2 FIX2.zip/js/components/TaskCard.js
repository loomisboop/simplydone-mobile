// SDAPWA v1.0.0 - Task Card Component
const TaskCard={render(a){return'<div class="task-card"></div>'}};window.TaskCard=TaskCard;console.log('✓ TaskCard loaded');
