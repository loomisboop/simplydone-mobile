// SDAPWA v1.0.0 - Top Bar Component
const TopBar={render(){return'<div class="top-bar"><button class="top-bar-back">←</button><h1 class="top-bar-title">SimplyDone</h1><div class="top-bar-actions"><span class="sync-indicator synced">🔄</span></div></div>'}};window.TopBar=TopBar;console.log('✓ TopBar loaded');
